import xml.dom.minidom
from xml.dom.minidom import Node


def parseFB2(fname):
    doc = xml.dom.minidom.parse(fname)

    last_name = ""
    book_title = ""

    # Обработка основной информации
    for title_node in doc.getElementsByTagName("title-info"):
        # Получение фамилии автора
        for author_node in title_node.getElementsByTagName("author"):
            for node2 in author_node.getElementsByTagName("last-name"):
                for node3 in node2.childNodes:
                    if node3.nodeType == Node.TEXT_NODE:
                        last_name = node3.data

        # Получение названия книги
        for book_node in title_node.getElementsByTagName("book-title"):
            for node2 in book_node.childNodes:
                if node2.nodeType == Node.TEXT_NODE:
                    book_title = node2.data

        # Получение жанра
        for book_node in title_node.getElementsByTagName("genre"):
            for node2 in book_node.childNodes:
                if node2.nodeType == Node.TEXT_NODE:
                    genre = node2.data

    return last_name, book_title, genre, fname


def textparseFB2(fname):
    with open(fname, 'r', encoding="utf-8") as f:
        return f.read()


textparseFB2("books/31972041.fb2")
