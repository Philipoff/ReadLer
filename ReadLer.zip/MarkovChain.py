import random


class MarkovChain:
    def __init__(self, book):
        self.s = book.split()
        self.s = [i.lower() for i in self.s]

        self.struct = dict()
        self.alp = set()

        self._gen_alp()
        self._train()
    
    # Генерация алфавита, из которого может состоять предложение
    def _gen_alp(self):
        for i in range(ord('a'), ord('z') + 1):
            self.alp.add(chr(i))

        for i in range(ord('A'), ord('Z') + 1):
            self.alp.add(chr(i))

        for i in range(ord('а'), ord('я') + 1):
            self.alp.add(chr(i))

        for i in range(ord('А'), ord('Я') + 1):
            self.alp.add(chr(i))

        self.alp.add('ё')
        self.alp.add('Ё')
    
    # Обработка строки(удаление всех ненужных символов и занесение их
    # в новый список, создание списка используемых в тексте слов)
    def _train(self):
        n = len(self.s)
        words = []
        self.end = []

        for i in range(n):
            if self.s[i][-1] == '.' or self.s[i][-1] == '?' or self.s[i][-1] == '!':
                self.end.append(self.s[i])
            for j in range(len(self.s[i])):
                if self.s[i][j] not in self.alp:
                    if j + 1 < len(self.s[i]):
                        self.s[i] = self.s[i][:j] + ' ' + self.s[i][j + 1:]
                    else:
                        self.s[i] = self.s[i][:-1]
            words += self.s[i].split()

        n = len(words)

        for i in range(n):
            if words[i] != "\n" and words[i] != "":
                self.struct[words[i]] = dict()

        for i in range(1, n):
            if words[i] == "" or words[i - 1] == "" or words[i] == "\n" or words[i - 1] == "\n":
                continue
            if words[i] not in self.struct[words[i - 1]].keys():
                self.struct[words[i - 1]][words[i]] = 1

        if words[len(words) - 1] not in self.struct.keys():
            self.struct[words[len(words) - 1]] = dict()

        self.x = list(self.struct.keys())

    @staticmethod
    # Рандомная генерация предложения
    def _chose(mapp):
        random.seed(version=2)
        ver = random.randint(1, 100)
        mapp = dict(sorted(mapp.items(), key=lambda kv: kv[1]))
        arr = list(mapp.keys())
        sum = 0

        for i in range(len(arr)):
            sum += mapp[arr[i]]
            if ver / 100 <= sum:
                return arr[i]
    
    # Объединение строки
    def _solve(self, word, n, string):
        if n == 0 or (word not in self.struct.keys()):
            return string
        return self._solve(self._chose(self.struct[word]), n - 1, string + word + " ")
    
    # Создание строки, её возвращение
    def generate(self):
        random.seed(version=2)
        idx = random.randint(0, len(self.x) - 1)
        cnt = random.randint(7, 13)
        ans = self._solve(self.x[idx], cnt, "")
        id = random.randint(0, len(self.end) - 1)
        return ans[0].upper() + ans[1:] + self.end[id]