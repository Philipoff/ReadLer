import sys
import sqlite3
from PyQt5.QtWidgets import (QPushButton, QLineEdit, QLabel, QMessageBox,
                             QGridLayout, QColorDialog, QApplication,
                             QTableWidget, QTableWidgetItem, QFileDialog,
                             QTextBrowser, QHeaderView)
from PyQt5.QtGui import QStandardItem, QStandardItemModel, QIcon
from PyQt5 import QtWidgets, QtCore
from ParseFB2 import parseFB2, textparseFB2
from MarkovChain import MarkovChain

# Первое окно, в котором отображаются данные о книгах
class MainWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.secondWin = None
        self.bookid = 0
        self.build()

    # Отрисовка основного окна
    def build(self):
        self.setWindowTitle('ReadLer')
        self.setWindowIcon(QIcon("icons/main_icon.png"))
        self.setGeometry(100, 100, 800, int(800 / 2 ** (1/ 2)))
        self.Layout = QGridLayout(self)

        # Кнопка добавления книги
        self.btn1 = QPushButton(self)
        self.btn1.clicked.connect(self.addbook)
        self.btn1.setIcon(QIcon('icons/addbook.jpg'))
        self.btn1.setText('Добавить книгу')

        # Кнопка удаления книги
        self.btn2 = QPushButton(self)
        self.btn2.clicked.connect(self.deletebook)
        self.btn2.setIcon(QIcon('icons/deletebook.png'))
        self.btn2.setText('Удалить книгу')

        # Кнопка просмотра книги
        self.btn3 = QPushButton(self)
        self.btn3.clicked.connect(self.openbook)
        self.btn3.setIcon(QIcon('icons/readbook.png'))
        self.btn3.setText('Просмотр книги')

        # Кнопка закрытия приложения
        self.btn4 = QPushButton(self)
        self.btn4.clicked.connect(self.closewindow)
        self.btn4.setIcon(QIcon('icons/closewindow.png'))
        self.btn4.setText('Закрыть ReadLer')

        # Создание списка книг
        self.books = QTableWidget(self)
        self.books.setColumnCount(3)
        self.rowscount = 1
        self.books.setRowCount(self.rowscount)
        self.books.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.books.setHorizontalHeaderLabels(["Author", "Name", "Genre"])

        # Получение всех книг и их id из базы данных
        conn = sqlite3.connect('bookshelf.db')
        cur = conn.cursor()

        self.result = cur.execute("""

                    SELECT * FROM Books

        """).fetchall()
        self.ids = [i[0] for i in self.result]
        conn.close()

        # Заполнение списка книг
        for elem in range(len(self.result)):
            self.bookid = elem
            self.books.setItem(self.bookid, 0, QTableWidgetItem(self.result[elem][1]))
            self.books.setItem(self.bookid, 1, QTableWidgetItem(self.result[elem][2]))
            self.books.setItem(self.bookid, 2, QTableWidgetItem(self.result[elem][3]))
            self.rowscount += 1
            self.books.setRowCount(self.rowscount)

        # Добавление всех виджетов на экран
        self.Layout.addWidget(self.btn1, 1, 1, 1, 1)
        self.Layout.addWidget(self.btn2, 1, 2, 1, 1)
        self.Layout.addWidget(self.btn3, 1, 3, 1, 1)
        self.Layout.addWidget(self.btn4, 1, 4, 1, 1)
        self.Layout.addWidget(self.books, 2, 1, 2, 4)

    # Создание второго окна под текст книги
    def openbook(self):
        try:
            if not self.secondWin:
                self.secondWin = SecondWindow(self)
            self.secondWin.books = self.books
            try:
                self.secondWin.show()
            except RuntimeError:
                self.secondWin = SecondWindow(self)
            self.secondWin.show()
        except AttributeError:
            QMessageBox.warning(self, "Ошибка", "Выберите книгу для просмотра")

    # Функция добавления книги в список
    def addbook(self):
        book = QFileDialog.getOpenFileName()[0]

        for i in range(0, 1000):
            if i not in self.ids:
                self.ids.append(i)
                self.bookid = i
                break

        # Проверка книги на нужный формат и добавление её в бд и список
        if book[-3:] == "fb2":
            author, name, genre, path = parseFB2(book)

            conn = sqlite3.connect('bookshelf.db')
            cur = conn.cursor()
            cur.execute("""

                    INSERT INTO books(id, name, author, genre, path) VALUES(?, ?, ?, ?, ?)

                    """, (self.bookid, name, author, genre, path)).fetchall()

            conn.commit()
            conn.close()
            self.rowscount += 1
            self.books.setRowCount(self.rowscount)
            self.build_shelf()
        else:
            QMessageBox.warning(self, "Ошибка", "Формат книги должен быть FB2")

    # Удаление книги из списка и из базы данных
    def deletebook(self):
        # Получение названия книги из отмеченной колонки
        try:
            row = self.books.currentRow()
            text = self.books.takeItem(row, 1).text()
            self.books.setItem(row, 1, QTableWidgetItem(text))
        except AttributeError:
            QMessageBox.warning(self, "Ошибка", "Выберите книгу для удаления.")
            return

        conn = sqlite3.connect('bookshelf.db')
        cur = conn.cursor()

        book = cur.execute("""

                            SELECT * FROM Books WHERE name=?

                """, (text, )).fetchall()[0]

        msg = 'Вы уверенны, что хотите удалить "' + str(book[2]) + '"?'
        question = QMessageBox.question(self, 'Подтверждение решения',  msg,
                                        QtWidgets.QMessageBox.Yes,
                                        QtWidgets.QMessageBox.No)

        if question == QMessageBox.Yes:
            cur.execute("""

                                        DELETE FROM Books WHERE name=?

                        """, (text,)).fetchall()
            self.ids.remove(book[0])

        conn.commit()
        conn.close()
        self.rowscount -= 1
        self.books.setRowCount(self.rowscount)
        self.build_shelf()

    # Пересоздание списка книг, пользуясь базой данных
    def build_shelf(self):
        conn = sqlite3.connect('bookshelf.db')
        cur = conn.cursor()

        self.result = cur.execute("""

                            SELECT * FROM Books

                """).fetchall()
        conn.close()

        self.books.clear()
        self.bookid = 0
        for elem in range(len(self.result)):
            Item = QTableWidgetItem
            self.books.setItem(self.bookid, 0, Item(self.result[elem][1]))
            self.books.setItem(self.bookid, 1, Item(self.result[elem][2]))
            self.books.setItem(self.bookid, 2, Item(self.result[elem][3]))
            self.bookid += 1

    # Функция закрытия основного окна
    def closewindow(self):
        self.close()


# Второе окно, в котором отображается текст книги
class SecondWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent, QtCore.Qt.Window)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.books = parent.books
        self.build()

    # Постройка окна
    def build(self):
        # Получение имени книги
        row = self.books.currentRow()
        text = self.books.takeItem(row, 1).text()
        self.books.setItem(row, 1, QTableWidgetItem(text))

        # Получение данных о книге из базы данных
        conn = sqlite3.connect('bookshelf.db')
        cur = conn.cursor()

        book = cur.execute("""

                                    SELECT * FROM Books WHERE name=?

                        """, (text,)).fetchall()[0]

        conn.close()
        # Изменение названия окна
        self.setWindowTitle(book[2])
        self.setWindowIcon(QIcon("icons/book_icon.jpg"))
        self.setGeometry(300, 100, 900, 500)

        self.layout = QGridLayout(self)

        # Кнопка закрытия книги
        self.close_button = QPushButton(self)
        self.close_button.setText("Закрыть книгу")
        self.close_button.clicked.connect(self.close_book)

        # Окно отображения текста
        self.text = QTextBrowser(self)
        book_text = self.book_treatment(textparseFB2(book[4]))
        self.text.setText(book_text)

        # Кнопка генерации цепи
        self.markov_chain_btn = QPushButton(self)
        self.markov_chain_btn.setText("Сгенерировать случайный текст")
        self.markov_chain_btn.clicked.connect(lambda x: self.gentext(book_text))

        # Добавление всех элементов окна в разметку
        self.layout.addWidget(self.markov_chain_btn, 1, 1, 1, 1)
        self.layout.addWidget(self.close_button, 1, 2, 1, 1)
        self.layout.addWidget(self.text, 2, 1, 1, 2)

    # Генерация рандомного сообщения
    def gentext(self, book):
        text_gen = MarkovChain(book)
        text = text_gen.generate()
        QMessageBox.information(self, "Случайное предложение", text)

    # Закрытие книжки (второго окна)
    def close_book(self):
        self.close()

    # Обработка текста книги для отображения читабельного вида
    def book_treatment(self, b):
        # Удаление всех ненужных атрибутов, внутри которых лежит полезная информация
        b = b.replace("</p>", "  ").replace("<p>", "  ")
        b = b.replace("<empty-line/>", "\n").replace("<empty-line/>", "\n")
        b = b.replace("</first-name>", "").replace("</author>", "")
        b = b.replace("<middle-name>", " ").replace("</middle-name>", "")
        b = b.replace("<last-name>", " ").replace("</last-name>", "\n")
        b = b.replace("<text-author>", " ").replace("</text-author>", "\n")
        b = b.replace("<emphasis>", "").replace("</emphasis>", "")
        b = b.replace("<epigraph>", "\n").replace("</epigraph>", "\n")
        b = b.replace("<annotation>", "\n").replace("</annotation>", "\n")
        b = b.replace("<strong>", "").replace("</strong>", "")
        b = b.replace("<book-title>", "").replace("</book-title>", "")
        b = b.replace("<section>", "\n").replace("</section>", "")
        b = b.replace("<title>", "").replace("</title>", "")
        b = b.replace("<subtitle>", "\n").replace("</subtitle>", "\n")
        b = b.replace("<myheader>", "\n").replace("</myheader>", "\n")
        b = b.replace("<v>", "\n").replace("</v>", "")
        b = b.replace("&quot;", "\n")

        book = b
        # Нахождение имени и конца книги
        name_x = book.find("<first-name>")
        book_end_x = book.find("</body>")
        book = book[name_x + len("<first-name>"):book_end_x - 10]

        # Нахождение и удаление аттрибутовне не для чтения и их содержимого
        # Например, картинки, ссылки и разметку текста
        id_x1, id_x2 = book.find("<id>"), book.find("</id>")
        book = book[:id_x1] + '\n' + book[id_x2 + 5:]
        id_x1, id_x2 = book.find("<title>"), book.find("</title>")
        book = book[:id_x1] + book[id_x2 + 8:]
        id_x1, id_x2 = book.find("<keywords>"), book.find("<title>")
        if id_x1 < id_x2:
            book = book[:id_x1] + book[id_x2 + 7:]

        id_x1, id_x2 = book.find("<a"), book.find("</a>")
        while '</a>' in book:
            if id_x2 != -1 and id_x1 != -1 and id_x2 - id_x1 < 500:
                id_x1, id_x2 = book.find("<a"), book.find("</a>")
                book = book[:id_x1] + book[id_x2 + 4:]
            else:
                break
        id_x1 = book.find('Конец ознакомительного фрагмента')
        if id_x1 != -1:
            book = book[:id_x1 - 43]
            book += '\n\nКонец ознакомительного фрагмента'
        id_x1 = book.rfind('<cite>')
        if id_x1 != -1:
            book = book[:id_x1]
        id_x2 = book.rfind(">")
        book_len = len(book)
        while book_len - id_x2 < 1000:
            book = book[:id_x2]
            book_len = len(book)
            id_x2 = book.rfind(">")

        id_x1 = book.rfind("<")
        while book_len - id_x1 < 50:
            book = book[:id_x1]
            book_len = len(book)
            id_x1 = book.rfind("<")

        if "<body>" in book:
            id_x1 = book.find("<")
            id_x2 = book.find("<body>")
            book = book[:id_x1] + book[id_x2 + 6:]

        while "<" in book[400:]:
            id_x1, id_x2 = book.find("<"), book.find(">")
            if id_x2 - id_x1 < 100 and id_x1 != -1 and id_x2 != -1:
                book = book[:id_x1] + book[id_x2 + 1:]
            else:
                break

        return book


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())